# Hello Dream

Simple hello-world using the [Dream](https://github.com/aantron/dream) web framework.

Used to demonstrate some ELF quirks for the blog article: [Debugging Linking Problems in OCaml and Esy](https://www.marigold.dev/post/debugging-linking-problems-in-ocaml-and-esy).
