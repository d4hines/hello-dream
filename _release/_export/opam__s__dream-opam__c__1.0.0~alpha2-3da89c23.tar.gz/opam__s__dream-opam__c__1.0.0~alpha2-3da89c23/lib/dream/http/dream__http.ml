(** @canonical Dream__http.Adapt *)
module Adapt = Dream__http__Adapt


(** @canonical Dream__http.Error_handler *)
module Error_handler = Dream__http__Error_handler


(** @canonical Dream__http.Http *)
module Http = Dream__http__Http
