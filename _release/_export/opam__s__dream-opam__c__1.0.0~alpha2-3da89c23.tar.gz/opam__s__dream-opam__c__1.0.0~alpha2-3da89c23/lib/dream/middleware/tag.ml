#1 "src/middleware/tag.eml.ml"
(* This file is part of Dream, released under the MIT license. See LICENSE.md
   for details, or visit https://github.com/aantron/dream.

   Copyright 2021 Anton Bachin *)



module Dream = Dream__pure.Formats

(* TODO Include the path prefix. *)
let form_tag ?enctype ~action request =
  let enctype =
    match enctype with
    | Some _ -> " enctype=\"multipart/form-data\""
    | None -> ""
  in
  let token = Csrf.csrf_token request in
let ___eml_buffer = Buffer.create 4096 in
(Buffer.add_string ___eml_buffer "<form method=\"POST\" action=\"");
(Printf.bprintf ___eml_buffer "%s" (Dream.html_escape (
#18 "src/middleware/tag.eml.ml"
                                  action 
)));
(Buffer.add_string ___eml_buffer "\"");
(Printf.bprintf ___eml_buffer "%s" (
#18 "src/middleware/tag.eml.ml"
                                                 enctype 
));
(Buffer.add_string ___eml_buffer ">\n<input name=\"");
(Printf.bprintf ___eml_buffer "%s" (
#19 "src/middleware/tag.eml.ml"
                    Csrf.field_name 
));
(Buffer.add_string ___eml_buffer "\" type=\"hidden\" value=\"");
(Printf.bprintf ___eml_buffer "%s" (
#19 "src/middleware/tag.eml.ml"
                                                                  token 
));
(Buffer.add_string ___eml_buffer "\">\n");
(Buffer.contents ___eml_buffer)
