(** @canonical Dream__pure.Body *)
module Body = Dream__pure__Body


(** @canonical Dream__pure.Formats *)
module Formats = Dream__pure__Formats


(** @canonical Dream__pure.Inmost *)
module Inmost = Dream__pure__Inmost


(** @canonical Dream__pure.Method *)
module Method = Dream__pure__Method


(** @canonical Dream__pure.Status *)
module Status = Dream__pure__Status
