(** @canonical H2_lwt.H2_lwt_intf *)
module H2_lwt_intf = H2_lwt__H2_lwt_intf
