(** @canonical Dream__cipher.Cipher *)
module Cipher = Dream__cipher__Cipher


(** @canonical Dream__cipher.Random *)
module Random = Dream__cipher__Random
