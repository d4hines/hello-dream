(** @canonical Httpaf_lwt.Httpaf_lwt_intf *)
module Httpaf_lwt_intf = Httpaf_lwt__Httpaf_lwt_intf
