type t =
  | Waiting
  | Ready
  | Complete
