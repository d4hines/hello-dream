type t =
 | Ready
 | Wait
 | Complete
