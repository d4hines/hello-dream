(** @canonical Dream__graphql.Graphql *)
module Graphql = Dream__graphql__Graphql
