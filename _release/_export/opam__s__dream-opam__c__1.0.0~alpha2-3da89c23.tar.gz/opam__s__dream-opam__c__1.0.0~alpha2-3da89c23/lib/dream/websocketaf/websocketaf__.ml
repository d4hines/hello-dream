(** @canonical Websocketaf.Client_connection *)
module Client_connection = Websocketaf__Client_connection


(** @canonical Websocketaf.Client_handshake *)
module Client_handshake = Websocketaf__Client_handshake


(** @canonical Websocketaf.Handshake *)
module Handshake = Websocketaf__Handshake


(** @canonical Websocketaf.Optional_thunk *)
module Optional_thunk = Websocketaf__Optional_thunk


(** @canonical Websocketaf.Reader *)
module Reader = Websocketaf__Reader


(** @canonical Websocketaf.Server_connection *)
module Server_connection = Websocketaf__Server_connection


(** @canonical Websocketaf.Websocket *)
module Websocket = Websocketaf__Websocket


(** @canonical Websocketaf.Websocket_connection *)
module Websocket_connection = Websocketaf__Websocket_connection


(** @canonical Websocketaf.Wsd *)
module Wsd = Websocketaf__Wsd
